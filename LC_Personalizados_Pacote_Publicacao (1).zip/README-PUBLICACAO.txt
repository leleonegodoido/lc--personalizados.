LC PERSONALIZADOS — PACOTE INICIAL DE PUBLICAÇÃO

O que contém:
- index.html: catálogo atual com painel de demonstração, pesquisa externa de imagens e assistente de prompt para IA.

IMPORTANTE:
Esta versão ainda usa armazenamento local do navegador (localStorage).
Não é uma loja multiusuário nem possui autenticação segura ou armazenamento online.
Não publique com produtos/dados sensíveis esperando sincronização entre aparelhos.

PUBLICAÇÃO ESTÁTICA (somente para pré-visualização):
1. Crie uma conta no GitHub e no Vercel.
2. Crie um repositório GitHub e envie o arquivo index.html.
3. No Vercel, importe esse repositório e faça o Deploy.
4. O Vercel oferecerá um endereço gratuito *.vercel.app, se disponível.

ANTES DE USAR COMO LOJA REAL:
- Integrar Supabase Auth para login administrativo.
- Criar tabelas de produtos, categorias e configurações.
- Criar bucket privado/público de imagens com regras adequadas.
- Implementar políticas de acesso (RLS) para impedir que visitantes alterem produtos.
- Migrar o catálogo para ler/gravar no banco de dados e sincronizar em todos os aparelhos.
- Testar upload de até 50 imagens por produto, com validação de tamanho e limites do plano.

WhatsApp configurado no catálogo: +55 11 96962-7270.
Senha 1234 é apenas demonstrativa e não deve ser usada em produção.
